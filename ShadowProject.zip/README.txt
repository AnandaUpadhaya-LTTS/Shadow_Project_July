# Shadow_Project_July
TEST CASES


1. Calculate the downlink speed via http protocol on LTE Networks.
2. Calculate the uplink speed via http protocol with LTE Networks.
3. Calculate the downlink speed with FTP protocol in 3G Networks.
4. Calculate the uplink speed with FTP protocol in 3G Networks.
7. 4G LTE ipv6 Test with HTTP Protocol: APN set to ipv6 only.
8. 4G LTE ipv6 Test with HTTP Protocol: APN set to ipv4 only.
9. 4G LTE ipv4 and ipv6 Test with HTTP Protocol: APN set to ipv4 only.
10. 4G LTE ipv4 and ipv6 Test with HTTP Protocol: APN set to ipv4 and ipv6.
11. 4G LTE ipv6 Test with FTP Protocol: APN set to ipv6 only.
12. 4G LTE ipv6 Test with FTP Protocol: APN set to ipv4 only.
13. 4G LTE ipv4 and ipv6 Test with FTP Protocol: APN set to ipv4 only.
14. 4G LTE ipv4 and ipv6 Test with FTP Protocol: APN set to ipv4 and ipv6.
15. 4G LTE attach and connection, ipv4.
16. 4G LTE attach and connection, ipv6.
17. Test sms while on data connection with WCDMA bands.
18. Test sms while on data connection with LTE bands.
19. Test MO call while on data connection with WCDMA bands.
20. Test MO call while on data connection with LTE bands.
21. Simultaneous data and voice call with WCDMA bands.
22. Simultaneous data and voice call with LTE bands.
23. Bidirectional data transfer with WCDMA bands.
24. Bidirectional data transfer with LTE bands.
